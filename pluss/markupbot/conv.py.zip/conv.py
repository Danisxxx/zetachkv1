from configs._def_main_ import *
import requests

async def convert_currency(amount, currency_code):
    response = requests.get("https://api.exchangerate-api.com/v4/latest/USD")
    if response.status_code != 200:
        return None
    data = response.json()
    tasa = data["rates"].get(currency_code.upper(), 0)
    return round(amount * tasa, 2) if tasa else None

@rexbt('conv_usd')
async def handle_conversion_usd(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "USD")
    msg1 = dolar.format(dolar=amount, pesos_mexicanos=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('conv_mxn')
async def handle_conversion_mxn(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "MXN")
    msg1 = mxn.format(dolar=amount, pesos_mexicanos=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('conv_arg')
async def handle_conversion_arg(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "ARS")
    msg1 = arg.format(dolar=amount, pesos_argentinos=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('conv_eur')
async def handle_conversion_eur(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "EUR")
    msg1 = eur.format(dolar=amount, euros=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('conv_col')
async def handle_conversion_col(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "COP")
    msg1 = col.format(dolar=amount, pesos_colombianos=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('conv_per')
async def handle_conversion_per(client, msg):
    amount = 1
    converted_amount = await convert_currency(amount, "PEN")
    msg1 = per.format(dolar=amount, sol_peruano=converted_amount)
    await msg.edit_message_text(msg1, reply_markup=back_buttons)

@rexbt('back')
async def go_back_to_menu(client, msg):
    ms = convtext.format() 
    await msg.edit_message_text(
        ms,
        reply_markup=conversion_buttons
    )
